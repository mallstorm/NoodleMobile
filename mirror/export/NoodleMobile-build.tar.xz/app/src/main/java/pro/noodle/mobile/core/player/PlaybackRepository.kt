package pro.noodle.mobile.core.player

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import pro.noodle.mobile.core.adapter.AdapterDefinition
import pro.noodle.mobile.core.model.MediaSource
import pro.noodle.mobile.core.model.TextTrack
import pro.noodle.mobile.core.model.VideoItem
import pro.noodle.mobile.core.network.NetworkPolicy
import pro.noodle.mobile.core.network.SecureHttpClient
import pro.noodle.mobile.core.resolver.ResolverFetcher
import pro.noodle.mobile.core.resolver.ResolverPipeline
import pro.noodle.mobile.core.security.UrlPolicy
import pro.noodle.mobile.core.source.SourceRuntimeDiagnosticsStore
import pro.noodle.mobile.core.web.SandboxedWebExtractor
import java.net.URI

data class PlaybackSession(
    val video: VideoItem,
    val networkPolicy: NetworkPolicy,
    val sourceKey: String,
)

data class PlaybackLoadResult(
    val success: Boolean,
    val session: PlaybackSession? = null,
    val errorCode: String = "",
    val errorMessage: String = "",
)

class PlaybackRepository(context: Context, private val http: SecureHttpClient = SecureHttpClient()) {
    private val webExtractor = SandboxedWebExtractor(context.applicationContext)
    private val diagnostics = SourceRuntimeDiagnosticsStore(context.applicationContext)

    suspend fun resolve(video: VideoItem, adapter: AdapterDefinition): PlaybackLoadResult = withContext(Dispatchers.IO) {
        if (!isStaticEntryAllowed(video.watchUrl, adapter)) {
            diagnostics.recordPlayback(adapter.id, video.watchUrl, "", "entry_blocked", "PLAYBACK_ENTRY_BLOCKED")
            return@withContext PlaybackLoadResult(
                false,
                errorCode = "PLAYBACK_ENTRY_BLOCKED",
                errorMessage = "Страница ролика не прошла исходную SNP/security policy.",
            )
        }

        // Exact public HTTPS hosts discovered while following the resolver chain. We never add
        // wildcard hosts and never allow HTTP/private addresses. This handles rotating CDN/iframe
        // domains without turning the SNP policy into an unrestricted network client.
        val discoveredHosts = linkedSetOf<String>()
        val page = fetchWithSafeDiscoveredRedirects(video.watchUrl, adapter, discoveredHosts)
        var initialText = page.text
        var initialUrl = page.finalUrl.ifBlank { video.watchUrl }
        var usedWeb = false

        if (!page.success) {
            if (!adapter.allowJavaScript) {
                diagnostics.recordPlayback(adapter.id, video.watchUrl, "", "page_failed", page.errorCode)
                return@withContext PlaybackLoadResult(false, errorCode = page.errorCode, errorMessage = page.errorMessage)
            }
            val extracted = webExtractor.extract(video.watchUrl, adapter, additionalAllowedHosts = discoveredHosts)
            if (!extracted.success) {
                val code = extracted.errorCode.ifBlank { page.errorCode }
                diagnostics.recordPlayback(adapter.id, video.watchUrl, "", "web_failed", code)
                return@withContext PlaybackLoadResult(
                    false,
                    errorCode = code,
                    errorMessage = extracted.errorMessage.ifBlank { page.errorMessage },
                )
            }
            initialText = extracted.html
            initialUrl = extracted.finalUrl.ifBlank { video.watchUrl }
            usedWeb = true
        }

        val fetcher = ResolverFetcher { url ->
            fetchResolverText(url, adapter, discoveredHosts)
        }
        var resolved = ResolverPipeline.resolve(initialText, initialUrl, adapter.engine, adapter.viewStrategies, fetcher)
        var safeSources = resolved.sources.filter { admitMediaSource(it, adapter, discoveredHosts) }

        // Static HTML sometimes loads successfully but the real player config appears only after JS.
        if (safeSources.isEmpty() && adapter.allowJavaScript && !usedWeb) {
            val extracted = webExtractor.extract(
                initialUrl,
                adapter,
                additionalAllowedHosts = discoveredHosts,
            )
            if (extracted.success) {
                val jsResolved = ResolverPipeline.resolve(
                    extracted.html,
                    extracted.finalUrl.ifBlank { initialUrl },
                    adapter.engine,
                    adapter.viewStrategies,
                    fetcher,
                )
                if (jsResolved.success || jsResolved.sources.isNotEmpty()) resolved = jsResolved
                safeSources = resolved.sources.filter { admitMediaSource(it, adapter, discoveredHosts) }
            }
        }

        if (!resolved.success && safeSources.isEmpty()) {
            val code = resolved.errorCode.ifBlank { "PLAYBACK_RESOLVE_FAILED" }
            diagnostics.recordPlayback(adapter.id, video.watchUrl, "", "resolve_failed", code)
            return@withContext PlaybackLoadResult(
                false,
                errorCode = code,
                errorMessage = resolved.errorMessage.ifBlank { "Resolver не смог извлечь воспроизводимый поток." },
            )
        }

        val safeTextTracks = resolved.tracks.filter { admitTextTrack(it, adapter, discoveredHosts) }
        if (safeSources.isEmpty()) {
            val blockedHosts = resolved.sources.mapNotNull { source -> hostOf(source.url) }.distinct().take(6)
            val hostDetails = blockedHosts.joinToString(", ").takeIf { it.isNotBlank() }
                ?.let { " Заблокированные hosts: $it." }.orEmpty()
            diagnostics.recordPlayback(adapter.id, video.watchUrl, "", "blocked_sources", "PLAYBACK_NO_ALLOWED_SOURCE")
            return@withContext PlaybackLoadResult(
                false,
                errorCode = "PLAYBACK_NO_ALLOWED_SOURCE",
                errorMessage = "Resolver нашёл media URL, но поток не прошёл HTTPS/public-host policy.$hostDetails",
            )
        }

        val sessionPolicy = policyFor(adapter, discoveredHosts)
        // Before handing a list to PlayerScreen, cheaply touch the first bytes/manifest of several
        // candidates through the exact source-isolated HTTP client. Dead 403/404 URLs are pushed to
        // the end and a confirmed source becomes default. This removes many avoidable red-screen
        // failures while retaining unprobed fallbacks for Media3.
        safeSources = prioritizeReachableSources(
            sources = safeSources,
            policy = sessionPolicy,
            sourceKey = adapter.id,
            referer = resolved.playerPageUrl.ifBlank { initialUrl },
        )
        val selected = safeSources.firstOrNull { it.isDefault } ?: safeSources.firstOrNull()
        diagnostics.recordPlayback(
            adapter.id,
            video.watchUrl,
            selected?.url.orEmpty(),
            if (selected != null) "resolved" else "no_source",
            if (selected == null) "PLAYBACK_NO_SOURCE" else "",
        )

        val out = video.copy(
            title = resolved.title.ifBlank { video.title },
            thumbnailUrl = resolved.thumbnailUrl
                .takeIf { it.isBlank() || isCurrentlyAllowed(it, adapter, discoveredHosts) }
                .orEmpty()
                .ifBlank { video.thumbnailUrl },
            playerPageUrl = resolved.playerPageUrl
                .takeIf { it.isBlank() || isCurrentlyAllowed(it, adapter, discoveredHosts) }
                .orEmpty()
                .ifBlank { video.watchUrl },
            sources = safeSources,
            variants = resolved.variants,
            audioTracks = resolved.audioTracks,
            textTracks = safeTextTracks,
        )
        PlaybackLoadResult(true, PlaybackSession(out, sessionPolicy, adapter.id))
    }

    private fun prioritizeReachableSources(
        sources: List<MediaSource>,
        policy: NetworkPolicy,
        sourceKey: String,
        referer: String,
    ): List<MediaSource> {
        if (sources.size <= 1) return sources
        val client = http.streamingClient(policy, sourceKey)
        val scored = sources.mapIndexed { index, source ->
            val confirmed = if (index < SOURCE_PREFLIGHT_LIMIT) runCatching {
                val request = Request.Builder()
                    .url(source.url)
                    .header("Range", "bytes=0-65535")
                    .header("Accept", "application/vnd.apple.mpegurl,application/dash+xml,video/*,*/*;q=0.5")
                    .apply { if (referer.isNotBlank()) header("Referer", referer) }
                    .build()
                client.newCall(request).execute().use { response ->
                    response.isSuccessful || response.code == 206
                }
            }.getOrDefault(false) else false
            Triple(source, confirmed, index)
        }
        val ordered = scored.sortedWith(
            compareByDescending<Triple<MediaSource, Boolean, Int>> { it.second }
                .thenByDescending { it.first.isDefault }
                .thenBy { it.third },
        ).map { it.first }
        val anyConfirmed = scored.any { it.second }
        return if (!anyConfirmed) ordered else ordered.mapIndexed { index, source -> source.copy(isDefault = index == 0) }
    }

    private suspend fun fetchWithSafeDiscoveredRedirects(
        url: String,
        adapter: AdapterDefinition,
        discoveredHosts: MutableSet<String>,
    ): pro.noodle.mobile.core.network.TextFetchResult {
        var result = http.fetchText(url, policyFor(adapter, discoveredHosts), adapter.id)
        var attempts = 0
        while (!result.success && result.errorCode == "URL_HOST_NOT_ALLOWED" && attempts < MAX_DISCOVERED_HOSTS) {
            if (!discoverPublicHttpsHost(result.finalUrl, adapter, discoveredHosts)) break
            attempts++
            result = http.fetchText(url, policyFor(adapter, discoveredHosts), adapter.id)
        }
        return result
    }

    private fun fetchResolverText(
        url: String,
        adapter: AdapterDefinition,
        discoveredHosts: MutableSet<String>,
    ): String? {
        if (!isCurrentlyAllowed(url, adapter, discoveredHosts) &&
            !discoverPublicHttpsHost(url, adapter, discoveredHosts)
        ) return null

        var attempts = 0
        while (attempts <= MAX_DISCOVERED_HOSTS) {
            val result = http.fetchTextBlocking(url, policyFor(adapter, discoveredHosts), adapter.id)
            if (result.success) return result.text
            if (result.errorCode != "URL_HOST_NOT_ALLOWED") return null
            if (!discoverPublicHttpsHost(result.finalUrl, adapter, discoveredHosts)) return null
            attempts++
        }
        return null
    }

    private fun admitMediaSource(
        source: MediaSource,
        adapter: AdapterDefinition,
        discoveredHosts: MutableSet<String>,
    ): Boolean {
        if (isCurrentlyAllowed(source.url, adapter, discoveredHosts)) return true
        if (!looksLikeMedia(source)) return false
        return discoverPublicHttpsHost(source.url, adapter, discoveredHosts)
    }

    private fun admitTextTrack(
        track: TextTrack,
        adapter: AdapterDefinition,
        discoveredHosts: MutableSet<String>,
    ): Boolean {
        if (isCurrentlyAllowed(track.url, adapter, discoveredHosts)) return true
        val lower = track.url.substringBefore('?').lowercase()
        if (!(lower.endsWith(".vtt") || lower.endsWith(".srt") || lower.endsWith(".ttml") || lower.endsWith(".xml"))) {
            return false
        }
        return discoverPublicHttpsHost(track.url, adapter, discoveredHosts)
    }

    private fun looksLikeMedia(source: MediaSource): Boolean {
        val lower = source.url.substringBefore('?').lowercase()
        val protocol = source.protocol.lowercase()
        val mime = source.mimeType.lowercase()
        return protocol in setOf("hls", "dash", "http", "https", "progressive") ||
            lower.endsWith(".m3u8") || lower.endsWith(".mpd") || lower.endsWith(".mp4") ||
            lower.endsWith(".webm") || lower.endsWith(".m4v") ||
            mime.startsWith("video/") || mime.contains("mpegurl") || mime.contains("dash+xml")
    }

    private fun discoverPublicHttpsHost(
        url: String,
        adapter: AdapterDefinition,
        discoveredHosts: MutableSet<String>,
    ): Boolean {
        val decision = UrlPolicy.evaluateNavigation(url, allowHttp = false, resolveDns = true)
        if (!decision.allowed) return false
        val host = hostOf(decision.normalizedUrl) ?: return false
        if (adapter.allowedHosts.isEmpty() || UrlPolicy.isHostAllowed(host, adapter.allowedHosts)) return true
        if (host in discoveredHosts) return true
        if (discoveredHosts.size >= MAX_DISCOVERED_HOSTS) return false
        discoveredHosts += host
        return true
    }

    private fun isStaticEntryAllowed(url: String, adapter: AdapterDefinition): Boolean {
        val decision = UrlPolicy.evaluateNavigation(url, allowHttp = false, resolveDns = true)
        if (!decision.allowed) return false
        val host = hostOf(decision.normalizedUrl) ?: return false
        return adapter.allowedHosts.isEmpty() || UrlPolicy.isHostAllowed(host, adapter.allowedHosts)
    }

    private fun isCurrentlyAllowed(
        url: String,
        adapter: AdapterDefinition,
        discoveredHosts: Set<String>,
    ): Boolean {
        val decision = UrlPolicy.evaluateNavigation(url, allowHttp = false, resolveDns = false)
        if (!decision.allowed) return false
        val host = hostOf(decision.normalizedUrl) ?: return false
        return adapter.allowedHosts.isEmpty() ||
            UrlPolicy.isHostAllowed(host, adapter.allowedHosts) ||
            host in discoveredHosts
    }

    private fun policyFor(adapter: AdapterDefinition, discoveredHosts: Set<String>): NetworkPolicy =
        NetworkPolicy(
            allowedHosts = (adapter.allowedHosts + discoveredHosts).distinct(),
            allowCookies = adapter.allowCookies,
            maxResponseBytes = 5 * 1024 * 1024,
        )

    private fun hostOf(url: String): String? = runCatching {
        URI(url).host?.lowercase()?.trimEnd('.')?.takeIf { it.isNotBlank() }
    }.getOrNull()

    companion object {
        private const val MAX_DISCOVERED_HOSTS = 8
        private const val SOURCE_PREFLIGHT_LIMIT = 4
    }
}
