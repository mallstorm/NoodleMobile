# Noodle Mobile 0.10.0-alpha10 — First Test APK Certification

The repository is configured to perform the first real Android certification in this exact order:

1. `:app:testDebugUnitTest`
2. `:app:lintDebug`
3. `:app:assembleDebug`
4. `tools/verify-apk.sh` using AAPT2
5. `:app:assembleDebugAndroidTest`
6. `tools/verify-test-apk.sh`
7. `:app:connectedDebugAndroidTest` only when a real device/emulator is connected

The main APK is accepted only if AAPT2 reports:
- package `pro.noodle.mobile`
- versionCode `100010`
- versionName `0.10.0-alpha10`
- minSdk 28
- targetSdk 37
- APK ZIP integrity, DEX and resources are present.

GitHub Actions workflow: `.github/workflows/android-ci.yml`.
Local/networked Linux entry point: `tools/bootstrap-android-toolchain.sh`, then `tools/ci-android-build.sh`.
