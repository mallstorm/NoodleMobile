# Stage 9 — First APK Certification

Target: **Noodle Mobile 0.10.0-alpha10** (`versionCode 90009`).

An APK may be labelled certified only after all of these complete on a real Android toolchain:

1. `:app:testDebugUnitTest`;
2. `:app:lintDebug`;
3. `:app:assembleDebug`;
4. `:app:assembleDebugAndroidTest`;
5. `tools/verify-apk.sh` passes;
6. AAPT2 reports package `pro.noodle.mobile`, versionCode `90009`, versionName `0.10.0-alpha10`, targetSdk 37;
7. APK ZIP integrity and SHA-256 are recorded.

Current execution runtime is **BLOCKED before Android compile** because Gradle/SDK/aapt2 are not installed and external DNS is unavailable. No APK is claimed by this source delivery.
