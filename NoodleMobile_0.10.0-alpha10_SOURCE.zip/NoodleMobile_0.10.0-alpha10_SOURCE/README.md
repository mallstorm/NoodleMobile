# Noodle Mobile 0.10.0-alpha10

Native Android port of **Noodle Desktop 1.9.0-alpha.10 / Stage 9 Schema v3 Repair**.

`0.10.0-alpha10` is the **First APK Certification / Toolchain Bootstrap** pass. All Stage 1–9 functionality is retained.

## Stage 10 highlights

- Android version `0.10.0-alpha10`, `versionCode 100010`; SNP compatibility remains `1.9.0`.
- Stable dependency correction: Compose BOM `2026.06.00`; Media3 `1.10.1`; AGP `9.3.1`; KSP `2.3.11`.
- compile/target API 37 with Build Tools 36.0.0.
- Reproducible Linux bootstrap script verifies Gradle 9.5.1 and Android command-line tools checksums before installing SDK 37.
- CI remains wrapper-independent and performs unit tests, lint, debug APK, androidTest APK and APK metadata certification.
- `verify-apk.sh` requires package `pro.noodle.mobile`, versionCode `100010`, versionName `0.10.0-alpha10`, targetSdk 37 and valid ZIP structure.
- Stale alpha3 note claiming adaptive offline is unavailable was removed; HLS/DASH selective offline has been implemented since alpha6.

## Verification

Run all source-level regressions:

```bash
./tools/verify-all-alpha10.sh
```

Strict local preflight:

```bash
./tools/build-check.sh
```

On a networked Linux host the complete toolchain can be bootstrapped with:

```bash
./tools/bootstrap-android-toolchain.sh
export ANDROID_SDK_ROOT="$PWD/.toolchain/android-sdk"
export PATH="$PWD/.toolchain/gradle-9.5.1/bin:$PATH"
./tools/ci-android-build.sh
```

A delivery must not claim a verified APK until the actual Android Gradle tasks and `verify-apk.sh` complete successfully.
