# Noodle Desktop — Stage 9: Schema v3, dependency graph и устойчивое восстановление

Версия: **1.9.0-alpha.10**  
Дата: **2026-08-07**

## Реализовано

- SNP Schema v3 с `engine_dependencies` и отдельной `repair` policy.
- `TEngineDependencies`: required/optional/recommended зависимости, closure и проверка Registry.
- Безопасная миграция пользовательских SNP v1/v2 -> v3 с предварительной валидацией и snapshot.
- `TAdapterRepairPipeline` с `selector_relearn` и `resolver_refresh`.
- `TAdapterBreakageMonitor`: последовательные semantic failures, degraded/broken, threshold, cooldown и optional quarantine.
- Автодетектор выключен по умолчанию; минимальный интервал фоновой проверки — 6 часов, стандартный — 24 часа.
- CLI: `--broken-snp-check` и `--migrate-adapters-v3`.
- Source Center: Schema, Broken status, ручная проверка поломки и миграция v3.
- Диагностический ZIP включает последний `broken_snp` и `adapter_migration_v3` report.
- Пять bundled SNP переведены на Schema v3 и имеют автоматический repair выключенным.
- Adapter Studio и AdapterGenerator создают Schema v3.

## Безопасность

Repair не выполняет произвольный код адаптера, не обходит CAPTCHA/DRM/авторизацию и не расширяет `allowed_hosts`. Кандидат должен пройти обычную Schema/URL validation и реальный semantic test до замены рабочего пользовательского SNP. Bundled SNP автоматически не переписываются.

## Важное исправление ревизии

В ранней реализации Stage 9 migration candidate создавался рядом с `adapter.json`, поэтому мог попасть в snapshot/package manifest. Это исправлено: после валидации кандидат удаляется до создания snapshot; validated JSON остаётся в памяти и только затем записывается как новый `adapter.json`.

## Проверка

Добавлены DUnitX fixtures:

- `TestEngineDependencies`;
- `TestAdapterSchemaV3`;
- `TestAdapterMigration`.

Полная Delphi-компиляция и фактический запуск DUnitX требуют Windows + RAD Studio и не заявляются как выполненные в текущей среде.
