# Noodle Mobile 0.10.0-alpha10 — Stage 10 / First Test APK Candidate

## Результат прохода

Stage 10 выполнен как максимально строгая подготовка к первому настоящему Android APK. Функциональные слои предыдущих этапов сохранены: 15 движков, ResolverPipeline, защищённый HTTP/WebView, Media3 playback, Room/DataStore, progressive и HLS/DASH offline, SNP lifecycle, Marketplace, Trusted Keys, Adapter Studio, Diagnostics и Source Center.

Версия Android-приложения: `0.10.0-alpha10`, `versionCode=100010`.
SNP compatibility остаётся отдельным контрактом `1.9.0`.

## Build stack

- Android Gradle Plugin: 9.3.1
- compileSdk / targetSdk: 37
- minSdk: 28
- Gradle runner contract: 9.5.1
- Android Build Tools: 36.0.0
- JDK host: 21; Java bytecode target: 17
- Kotlin Gradle runtime override: 2.4.10
- KSP: 2.3.11
- Compose BOM: 2026.06.00
- Media3: 1.10.1 stable
- Room: 2.8.4
- DataStore: 1.2.1
- WorkManager: 2.11.2
- WebKit: 1.16.0

## AGP 9 / KSP stabilization

Проект сохраняет AGP 9 built-in Kotlin и не применяет `org.jetbrains.kotlin.android`. Для более новых KGP/KSP относительно встроенного AGP runtime в top-level `buildscript.dependencies` явно добавлены:

- `org.jetbrains.kotlin:kotlin-gradle-plugin:2.4.10`
- `com.google.devtools.ksp:symbol-processing-gradle-plugin:2.3.11`

Compose compiler подключается отдельным `org.jetbrains.kotlin.plugin.compose` той же Kotlin-линии.

## Compiler-facing Media3 audit

В исходниках Media3 1.10.1 отдельно проверено наличие используемых Noodle API:

- `DownloadHelper.Factory`
- `setDataSourceFactory`
- `setRenderersFactory`
- `setTrackSelectionParameters`
- `getDownloadRequest(id, data)`
- `DownloadHelper.createMediaSource(DownloadRequest, DataSource.Factory)`
- `DefaultDownloaderFactory(CacheDataSource.Factory, Executor)`
- `DownloadManager(Context, WritableDownloadIndex, DownloaderFactory)`
- `WorkManagerScheduler(Context, String)`
- используемый foreground `DownloadService` constructor
- `DownloadService.sendAddDownload(..., foreground)`

То есть adaptive-offline реализация alpha10 не зависит от API, присутствующего только в Media3 1.11 RC.

## First Test APK certification pipeline

`tools/ci-android-build.sh` выполняет этапы строго последовательно:

1. `:app:testDebugUnitTest`
2. `:app:lintDebug`
3. `:app:assembleDebug`
4. `tools/verify-apk.sh`
5. `:app:assembleDebugAndroidTest`
6. `tools/verify-test-apk.sh`
7. `:app:connectedDebugAndroidTest` только при наличии реального booted device/emulator.

`verify-apk.sh` принимает основной APK только если `aapt2 dump badging` подтверждает:

- package `pro.noodle.mobile`
- versionCode `100010`
- versionName `0.10.0-alpha10`
- minSdk 28
- targetSdk 37
- валидную ZIP-структуру
- наличие DEX
- наличие `resources.arsc`.

Отдельный `verify-test-apk.sh` проверяет androidTest APK.

## GitHub Actions

`.github/workflows/android-ci.yml` полностью подготовлен для сетевого Ubuntu runner и использует тот же `tools/ci-android-build.sh`. Логи публикуются даже при ошибке; APK artifacts публикуются только при полном success.

## Реально выполненные проверки

Итоговая переносимая матрица:

- Core: 29/29
- Stage 2: 21/21
- Stage 3: 43/43
- Stage 4: 26/26 + 88/88
- Stage 5: 26/26 + 78/78
- Stage 6: 15/15 + 75/75
- Stage 7: 19/19 + 57/57
- Stage 8: 31/31 + 62/62
- Stage 9: 25/25 + 29/29
- Stage 10: 27/27 + 28/28

**Итого: 679/679 named checks PASS.**

Kotlin parser syntax smoke: PASS.
Shell syntax smoke для certification scripts: PASS.

## Реальная попытка toolchain/bootstrap

`tools/bootstrap-android-toolchain.sh` был физически запущен в текущем runtime. Он остановился на загрузке Gradle:

`curl: (6) Could not resolve host: services.gradle.org`

Exit code: 6.

`tools/build-check.sh` также физически запущен. После успешных Stage 10 portable gates он дошёл до Android compile gate и завершился:

`BLOCKED: Android compile prerequisites are not present.`

Exit code: 3.

## Почему APK в этом пакете отсутствует

Это не ошибка, замаскированная под успешный build. В текущем runtime отсутствуют Gradle, Android SDK Platform 37 и aapt2, а внешний бинарный HTTPS недоступен. Подключённый GitHub connector авторизован, но возвращает ноль доступных репозиториев, поэтому подготовленный Actions workflow из этой сессии негде запустить.

Поэтому следующие действия **не заявляются выполненными**:

- Android dependency resolution
- Room KSP generation
- `testDebugUnitTest` через Android Gradle
- `lintDebug`
- AAPT2 resource processing
- Kotlin/Compose Android compilation
- D8/R8 packaging
- `assembleDebug`
- `assembleDebugAndroidTest`
- `verify-apk.sh` на настоящем Noodle APK
- instrumentation tests.

## Что требуется для первого настоящего APK

Нужен один реально доступный Android runner. Самый прямой путь для текущего проекта: пустой GitHub repository, доступный уже подключённому GitHub connector. После публикации этого source tree встроенный workflow способен выполнить exact certification pipeline и вернуть реальные compiler/lint логи и APK artifacts. Альтернатива — загрузить в текущую сессию полноценный Linux Android toolchain/offline environment вместе с нужным dependency cache.
