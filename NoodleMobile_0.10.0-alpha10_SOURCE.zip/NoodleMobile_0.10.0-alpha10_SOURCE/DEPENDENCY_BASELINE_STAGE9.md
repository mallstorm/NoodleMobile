# Noodle Mobile Stage 9 — dependency baseline

- AGP 9.3.1
- Gradle 9.5.1
- compileSdk/targetSdk 37
- Android Build Tools 36.0.0
- KGP / Compose compiler plugin 2.4.10
- KSP 2.3.11
- Compose BOM 2026.06.00
- Media3 1.10.1 stable
- Room 2.8.4
- DataStore 1.2.1
- WorkManager 2.11.2
- WebKit 1.16.0
- Android command-line tools Linux build 15859902 for bootstrap

Checksums used by bootstrap are hard-coded and validated before extraction.
