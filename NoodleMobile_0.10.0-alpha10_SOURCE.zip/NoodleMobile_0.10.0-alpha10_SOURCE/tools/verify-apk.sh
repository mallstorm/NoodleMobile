#!/usr/bin/env bash
set -euo pipefail
APK="${1:?usage: verify-apk.sh APK [AAPT2]}"
AAPT2="${2:-}"
[[ -f "$APK" ]] || { echo "ERROR: APK not found: $APK" >&2; exit 2; }
if [[ -z "$AAPT2" ]]; then
  SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  [[ -n "$SDK" ]] || { echo "ERROR: AAPT2 not supplied and Android SDK root is not set" >&2; exit 3; }
  AAPT2="$(find "$SDK/build-tools" -maxdepth 2 -type f -name aapt2 -print | sort -V | tail -1)"
fi
[[ -x "$AAPT2" ]] || { echo "ERROR: aapt2 not executable: $AAPT2" >&2; exit 4; }
BADGING="$($AAPT2 dump badging "$APK")"
echo "$BADGING" | grep -F "package: name='pro.noodle.mobile' versionCode='100010' versionName='0.10.0-alpha10'" >/dev/null || { echo "ERROR: APK identity mismatch" >&2; exit 5; }
echo "$BADGING" | grep -F "sdkVersion:'28'" >/dev/null || { echo "ERROR: APK minSdk mismatch" >&2; exit 6; }
echo "$BADGING" | grep -F "targetSdkVersion:'37'" >/dev/null || { echo "ERROR: APK targetSdk mismatch" >&2; exit 7; }
unzip -t "$APK" >/dev/null || { echo "ERROR: APK ZIP integrity failed" >&2; exit 8; }
unzip -l "$APK" | grep -E '(^|[[:space:]])classes[0-9]*\.dex$' >/dev/null || { echo "ERROR: APK contains no DEX" >&2; exit 9; }
unzip -l "$APK" | grep -F 'resources.arsc' >/dev/null || { echo "ERROR: APK contains no resources.arsc" >&2; exit 10; }
echo "APK=$APK"
sha256sum "$APK"
echo "APK_CERTIFICATION=PASS"
