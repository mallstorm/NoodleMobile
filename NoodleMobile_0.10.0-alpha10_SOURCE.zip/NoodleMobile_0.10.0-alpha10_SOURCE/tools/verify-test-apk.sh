#!/usr/bin/env bash
set -euo pipefail
APK="${1:?usage: verify-test-apk.sh TEST_APK [AAPT2]}"
AAPT2="${2:-}"
[[ -f "$APK" ]] || { echo "ERROR: androidTest APK not found: $APK" >&2; exit 2; }
if [[ -z "$AAPT2" ]]; then
  SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  [[ -n "$SDK" ]] || { echo "ERROR: AAPT2 not supplied and Android SDK root is not set" >&2; exit 3; }
  AAPT2="$(find "$SDK/build-tools" -maxdepth 2 -type f -name aapt2 -print | sort -V | tail -1)"
fi
[[ -x "$AAPT2" ]] || { echo "ERROR: aapt2 not executable: $AAPT2" >&2; exit 4; }
BADGING="$($AAPT2 dump badging "$APK")"
echo "$BADGING" | grep -F "package: name='pro.noodle.mobile.test'" >/dev/null || { echo "ERROR: androidTest package mismatch" >&2; exit 5; }
echo "$BADGING" | grep -F "targetSdkVersion:'37'" >/dev/null || { echo "ERROR: androidTest targetSdk mismatch" >&2; exit 6; }
unzip -t "$APK" >/dev/null || { echo "ERROR: androidTest APK ZIP integrity failed" >&2; exit 7; }
echo "ANDROID_TEST_APK=$APK"
sha256sum "$APK"
echo "ANDROID_TEST_APK_CERTIFICATION=PASS"
